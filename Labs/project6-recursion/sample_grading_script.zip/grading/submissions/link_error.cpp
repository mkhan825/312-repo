#include <stdio.h>
#include <stdint.h>

extern int nothing;
